from .bank_client import DemandeClient, BankConfig
# autres imports si nécessaire
