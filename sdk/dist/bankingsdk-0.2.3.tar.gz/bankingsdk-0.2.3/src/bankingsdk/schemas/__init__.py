from .schemas import DemandeSimple, DemandeDetailed, AgenceSimple, SituationProSimple, SituationFamilialeSimple, ApportSimple, AllDBSimple, AnalyticsResponse
